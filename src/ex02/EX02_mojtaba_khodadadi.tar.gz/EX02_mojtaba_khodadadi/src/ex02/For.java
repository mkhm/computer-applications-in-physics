package ex02;

import java.io.FileNotFoundException;

public class For {

    public static void main(String[] args) throws FileNotFoundException {
        for (int i = 0; i < 10; i++) {
            i++;
            System.out.println(i);
        }
    }
}
