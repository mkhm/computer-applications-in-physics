package ex01;

import java.io.FileNotFoundException;

public class EX1_A {
    public static void main(String[] args) throws FileNotFoundException {
        Coffee coffee = new Coffee(true);
        coffee.getFinalTempratureByOylerMethod(true);
    }
}
