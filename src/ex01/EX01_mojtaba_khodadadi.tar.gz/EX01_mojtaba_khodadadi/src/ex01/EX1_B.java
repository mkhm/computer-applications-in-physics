package ex01;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class EX1_B {

    public static void main(String[] args) throws FileNotFoundException {

        double deltats[] = {0.1, 0.05, 0.025, 0.01, 0.005, 0.001};
        PrintWriter file = new PrintWriter("cooling2.txt");

        Coffee coffee = new Coffee(false);

        for (int i = 0; i < deltats.length; i++) {
            coffee.setDeltat(deltats[i]);
            double deltaT = coffee.getFinalTemprature(false) - coffee.getFinalTempratureByOylerMethod(false);
            file.println(deltats[i] + "   " + deltaT);
        }
        file.flush();
    }
}
